## 1. Introducing Joins ##

SELECT * FROM facts
INNER JOIN cities ON cities.facts_id = facts.id
LIMIT 10;

## 3. Practicing Inner Joins ##

SELECT f.name country, c.name capital_city FROM cities c
INNER JOIN facts f ON f.id = c.facts_id 
WHERE c.capital = 1;